from django.contrib import admin
from.models import Fashion
# Register your models here.
admin.site.register(Fashion)

