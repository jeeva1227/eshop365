from django.shortcuts import render
from .models import Fashion

# Create your views here.
def index(request):
    fashs = Fashion.objects.all()

    return render(request,"index.html",{'fashs':fashs})


